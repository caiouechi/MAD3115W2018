//
//  CityTVC.swift
//  Day8SearchController
//
//  Created by Jigisha Patel on 2018-02-23.
//  Copyright © 2018 JK. All rights reserved.
//

import UIKit

class CityTVC: UITableViewController, UISearchResultsUpdating {
        
    //array to store filtered data
    var filteredCityList = cityList
    
    //create search controller
    let mySearchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = 90
        
        //set the searchController result updator
        mySearchController.searchResultsUpdater = self
    mySearchController.dimsBackgroundDuringPresentation = false
    mySearchController.definesPresentationContext = true
        
        //set the searchbar to display as table header
        tableView.tableHeaderView = mySearchController.searchBar
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return filteredCityList.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CityCell", for: indexPath) as! CityCell

        // Configure the cell...
        let row = indexPath.row
        
        cell.lblCity.text = filteredCityList[row].city
        cell.lblProvince.text = filteredCityList[row].province
  
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = indexPath.row
        let location = "\(filteredCityList[row].city), \(filteredCityList[row].province)"
        print("location : \(location)")
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        if mySearchController.searchBar.text! == "" {
            self.filteredCityList = cityList
        }
        else{
            filteredCityList = cityList.filter({$0.city.lowercased().contains(mySearchController.searchBar.text!.lowercased())})
        }
        self.tableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        self.tableView.reloadData()
    }
}

